<!DOCTYPE html>
<html>

<head>

    <title>LOGIN</title>
    <style>
        body {
            background: #1690A7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
        }

        * {
            font-family: sans-serif;
            box-sizing: border-box;
        }

        form {
            width: 400px;
            border: 2px solid #ccc;
            padding: 30px;
            background: #fff;
            border-radius: 15px;
        }

        h2 {
            text-align: center;
            margin-bottom: 40px;
        }

        input {
            display: black;
            border: 2px solid #ccc;
            width: 95%;
            padding: 10px;
            margin: 10px auto;
            border-radius: 5px;
        }

        label {
            color: #888;
            font-size: 15px;
            padding: 10px;
        }

        button {
            float: right;
            background: #555;
            padding: 10px 15px;
            color: #fff;
            border-radius: 5px;
            margin-right: 10px;
            border: none;
        }

        button:hover {
            opacity: .7;
        }

        .error {
            background: #f2DEDE;
            color: #A94;
        }

        .hello {
            color: green;
            font-size: 16px;
            margin-top: 5px;
        }

        .error {
            color: red;
            font-size: 16px;
            margin-top: 5px;
        }

        .logo {
            display: block;
            margin: 0 auto 20px;
            width: 100px;
            height: auto;
        }
    </style>

</head>

<body>
    <form action="" method="post">
        <?php
        $success = $fail = "";
        $sname = "localhost";
        $unmae = "root";
        $pass = "";
        $dbname = "idsdb";
        $conn = mysqli_connect($sname, $unmae, $pass, $dbname);
        if (!$conn) {
            echo "Connection failed!";
        }
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $email = $_POST['Email'];
            $password = $_POST['pass'];
            $sql = "SELECT * FROM applicants WHERE Email='$email' AND pwd='$password'";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) === 1) {
                header("Location: profile.php?email=" . urlencode($email));
            } else {
                $fail = "INVALID EMAIL OR PASSWORD";
            }
        }
        ?>
        <div>
            <img src="logo.png" alt="Logo" class="logo">
            <Label for="Email">Email:</Label>
            <input type="text" id="Email" name="Email" required>
        </div>
        <br>
        <div>
            <Label for="pass">Password:</Label>
            <input type="password" id="pass" name="pass" required>
        </div>
        <button type="submit">login</button>
        <br>
        <a href="registration.php">NewApplicant?</a>
        <div class="hello"><?php echo $success; ?></div>
        <div class="error"><?php echo $fail; ?></div>


    </form>
</body>

</html>
<!DOCTYPE html>
<html lang="en">
<head>

	<title>IDS Academy</title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="team" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/tooplate-style.css">

</head>
<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand">IDS Academy</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                         <li><a href="#home" class="smoothScroll">Home</a></li>
                         <li><a href="#feature" class="smoothScroll">Benifits</a></li>
                         <li><a href="#about" class="smoothScroll">About us</a></li>
                         <li><a href="#pricing" class="smoothScroll">Programs</a></li>
                         <li><a href="#contact" class="smoothScroll">Contact</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="#"><span>info@IDS.edu</span></a></li>
                    </ul>
               </div>

          </div>
     </section>


     <!-- FEATURE -->
     <section id="home" data-stellar-background-ratio="0.5">
          <div class="overlay"></div>
          <div class="container">
               <div class="row">
                    <div class="col-md-offset-3 col-md-6 col-sm-12">
                         <div class="home-info">
                              <h1>Welcome to IDS Academy!</h1>
                              <h3>Embark On A Journey Of Learning And Innovation With Our Comprehensive Web Programming Internship.
                                   As A Participant, You'll Gain Hands-On Experience Under The Guidance Of Our Seasoned Software 
                                   Engineers. You'll Delve Into The Core Principles Of Web Development, 
                                  Full Stack Programming, And The Latest Industry Trends.</h3>
<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <p>Ready to embark on a journey of coding excellence with IDS Academy? 
          Tell us, have we met before, or are you new to this exciting adventure?"</p>
        <button class="btn btn-primary" onclick="window.location.href='registration.php'">Lets Start</button>
        <button class="btn btn-primary" onclick="window.location.href='signin.php'">Welcome Back</button>
    </div>
</div>
<a><button class="btn btn-primary btn-lg" id="joinButton">Join us</button></a>
</div>
     </section>


     <!-- FEATURE -->
     <section id="feature" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h1>What you get</h1>
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-6">
                         <ul class="nav nav-tabs" role="tablist">
                              <li class="active"><a href="#tab01" aria-controls="tab01" role="tab" data-toggle="tab">In-depth Learning</a></li>

                              <li><a href="#tab02" aria-controls="tab02" role="tab" data-toggle="tab">HandOn_Experience</a></li>

                              <li><a href="#tab03" aria-controls="tab03" role="tab" data-toggle="tab">Mentorship</a></li>
                         </ul>

                         <div class="tab-content">
                              <div class="tab-pane active" id="tab01" role="tabpanel">
                                   <div class="tab-pane-item">
                                     <p>Our program offers comprehensive training in web development, 
                                        covering front-end and back-end technologies, programming languages, and frameworks.</p>
                                   </div>
                                   </div>
                              <div class="tab-pane" id="tab02" role="tabpanel">
                                   <div class="tab-pane-item">
                                        <p> Interns work on real projects, allowing them to apply their skills in a practical
                                             setting.</p>
                              </div>
</div>
                              <div class="tab-pane" id="tab03" role="tabpanel">
                                   <div class="tab-pane-item">
                                       <p>Access to experienced mentors who provide guidance, feedback, and 
                                        support throughout the internship</p>   
                                        </div>
                                        </div>
          </div>
          </div>
     </section>


     <!-- ABOUT -->
     <section id="about" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-offset-3 col-md-6 col-sm-12">
                         <div class="section-title">
                              <h1>About US</h1>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb">
                              <img src="images/team-image1.jpg" class="img-responsive" alt="Andrew Orange">
                              <div class="team-info team-thumb-up">
                                   <h2> Established in 1991</h2>
                                  <p>Integrated Digital Systems (IDS) is a software provider company with over three decades of experience.
                           </p>   </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb">
                              <div class="team-info team-thumb-down">
                                   <h2>Diverse Team</h2><p>We have a pool of more than a hundred software engineers with expertise in various
                                         domains.</p>
                              </div>
                              <img src="images/team-image2.jpg" class="img-responsive" alt="Catherine Soft">
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb">
                              <img src="images/team-image3.jpg" class="img-responsive" alt="Jack Wilson">
                              <div class="team-info team-thumb-up">
                                   <h2>Full-Cycle Software Development</h2>
                                   <p> We deliver full-cycle software development services and software products.</p>
                              </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </section>


     <!-- TESTIMONIAL -->
     <section id="testimonial" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="testimonial-image"></div>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="testimonial-info">
                              
                              <div class="section-title">
                                   <h1>What People Say</h1>
                              </div>

                              <div class="owl-carousel owl-theme">
                                   <div class="item">
                                        <h3>The program not only provided me with experience but also gave me the opportunity to
                                              work on real-world projects. The supportive mentors made
                                               my journey enjoyable and educational. 
                                             "</h3>
                                        <div class="testimonial-item">
                                             <img src="images/tst-image1.jpg" class="img-responsive" alt="Michael">
                                             <h4>Michael</h4>
                                        </div>
                                   </div>

                                   <div class="item">
                                        <h3>Choosing IDS Academy for my internship was one of the best decisions I made. 
                                             The practical skills I gained have been instrumental in landing my 
                                             first job as a full-stack developer.
                                            </h3>
                                        <div class="testimonial-item">
                                             <img src="images/tst-image2.jpg" class="img-responsive" alt="Sofia">
                                             <h4>Sofia</h4>
                                        </div>
                                   </div>

                                   <div class="item">
                                        <h3> The guidance and mentorship I received from the experienced instructors 
                                             were top-notch.</h3>
                                        <div class="testimonial-item">
                                             <img src="images/tst-image3.jpg" class="img-responsive" alt="Monica">
                                             <h4>Monica</h4>
                                        </div>
                                   </div>
                              </div>

                         </div>
                    </div>
                    
               </div>
          </div>
     </section>


     <!-- PRICING -->
     <section id="pricing" data-stellar-background-ratio="0.5">
    <div class="container">
        <div class="row">
        <div class="section-title">
                                   <h1>Choose Your Program</h1>
</div>
            <?php
            include("connection.php");
            $query = "SELECT p.*, i.Full_Name AS InstructorName FROM programs p
                      JOIN instructor i ON p.Instructors_InstructorID = i.ID";
            $result = mysqli_query($connection, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="col-md-4 col-sm-6">';
                    echo '<div class="pricing-thumb">';
                    echo '<div class="pricing-title">';
                    echo '<h2>' . $row['Title'] . '</h2>';
                    echo '</div>';
                    echo '<div class="pricing-info">';
                    echo '<p><strong>Description:</strong> ' . $row['Description'] . '</p>';
                    echo '<p><strong>Start Date:</strong> ' . $row['StartDate'] . '</p>';
                    echo '<p><strong>End Date:</strong> ' . $row['EndDate'] . '</p>';
                    echo '<p><strong>Program Capacity:</strong> ' . $row['MaxCapacity'] . '</p>';
                    echo '<p><strong>Current Capacity:</strong> ' . $row['CurrentCapacity'] . '</p>';
                    echo '<p><strong>Instructor:</strong> ' . $row['InstructorName'] . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo "No internship programs right now.";
            }

            mysqli_close($connection);
            ?>
        </div>
    </div>
</section>


     <!-- CONTACT -->
     <section id="contact" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-offset-1 col-md-10 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="section-title">
                                   <h1>Say hello to us</h1>
                              </div>

                              <div class="col-md-4 col-sm-4">
                                   <input type="text" class="form-control" placeholder="Full name" name="name" required="">
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <input type="email" class="form-control" placeholder="Email address" name="email" required="">
                              </div>
                              <div class="col-md-4 col-sm-4">
                                   <input type="submit" class="form-control" name="send message" value="Send Message">
                              </div>
                              <div class="col-md-12 col-sm-12">
                                   <textarea class="form-control" rows="8" placeholder="Your message" name="message" required=""></textarea>
                              </div>
                         </form>
                    </div>

               </div>
          </div>
     </section>       


     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="copyright-text col-md-12 col-sm-12">
                         <div class="col-md-6 col-sm-6">
                              <p>Copyright &copy; 2023 IDS Academy</p>
                         </div>

                         <div class="col-md-6 col-sm-6">
                              <ul class="social-icon">
                                   <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fa fa-twitter"></a></li>
                                   <li><a href="#" class="fa fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>

               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/jquery.stellar.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>
<script src="js/script.js"></script>
</body>
</html>
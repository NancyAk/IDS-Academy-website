<?php
include("connection.php");
$email = $_GET['email'];
$success = "";
$sql = "SELECT * FROM applicants WHERE Email = '$email'";
$result = $connection->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $applicantId = $row["ID"];
} else {
    die("Applicant not found.");
}
if (isset($_POST['new_password'])) {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    if ($newPassword === $confirmPassword) {
        $updateSql = "UPDATE applicants SET pwd = '$newPassword' WHERE ID = '$applicantId'";
        $result = $connection->query($updateSql);
        $success = "Password Updated Successfully";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicant Profile</title>
    <style>
        body {
            background-color: #0074cc;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .profile-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        .logo {
            width: 100px;
            /* Adjust the width as needed */
            margin-bottom: 20px;
        }

        .btn {
            background-color: #0074cc;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0055aa;
            /* Change color on hover */
        }

        .certificate-link {
            color: #0074cc;
            text-decoration: underline;
        }

        table {
            width: 100%;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>

<body>
    <div class="profile-container">
        <img src="logo.png" alt="Logo" class="logo">
        <p>Full Name: <?php echo $row["Full_Name"]; ?></p>
        <p>Mobile Number: <?php echo $row["Mobile_nb"]; ?></p>
        <p>Major: <?php echo $row["Major"]; ?></p>
        <p>University: <?php echo $row["University"]; ?></p>
        <h2>Enrolled Programs</h2>
        <table>
            <tr>
                <th>Program Title</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Google Classroom Code</th>
            </tr>
            <?php
            $programSql = "SELECT * FROM applicantprograms PA JOIN programs P ON PA.program_ID = P.Program_ID WHERE PA.Applicant_ID = '$applicantId'";
            $programResult = $connection->query($programSql);
            if ($programResult->num_rows > 0) {
                while ($programRow = $programResult->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $programRow["Title"] . "</td>";
                    echo "<td>" . $programRow["StartDate"] . "</td>";
                    echo "<td>" . $programRow["EndDate"] . "</td>";
                    echo "<td>" . $programRow["Google_Classroom_Code"] . "</td>";

                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>Not enrolled in any programs.</td></tr>";
            }
            ?>
        </table>
        <h2>Certificates</h2>
        <?php
        $certSql = "SELECT Certificate_File_Path FROM certificates WHERE Applicants_Applicant_ID = '$applicantId'";
        $certResult = $connection->query($certSql);
        if ($certResult->num_rows > 0) {
            while ($certRow = $certResult->fetch_assoc()) {
                echo '<a class="certificate-link" href="' . $certRow["Certificate_File_Path"] . '" target="_blank">Certificate Link</a><br>';
            }
        } else {
            echo "No certificates found.";
        }
        ?>
        <h2>Change Password</h2>
        <button class="btn" onclick="openPasswordChangePopup()">Change Password</button>
        <div id="passwordChangePopup" style="display: none;">
            <form method="POST">
                <input type="password" name="new_password" placeholder="New Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
                <button class="btn" type="submit">Change Password</button>
            </form>
        </div>
        <?php echo "$success" ?>


        <script>
            function openPasswordChangePopup() {
                var popup = document.getElementById("passwordChangePopup");
                popup.style.display = "block";
            }
        </script>
    </div>
</body>

</html>
<?php
include("connection.php");

$errors = [];
$full_name = $mobile_nb = $university = $major = $password = $program_id = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST["full_name"];
    $mobile_nb = $_POST["mobile_nb"];
    $university = $_POST["university"];

    $major = $_POST["major"];

    $email = $_POST["email"];
    $password = $_POST["password"];
    $program_id = $_POST["program"];
    $url = "images/home-bg.jpg";
    $check_email_query = "SELECT COUNT(*) FROM Applicants WHERE Email = ?";
    $stmt_check_email = mysqli_prepare($connection, $check_email_query);
    mysqli_stmt_bind_param($stmt_check_email, "s", $email);
    mysqli_stmt_execute($stmt_check_email);
    mysqli_stmt_bind_result($stmt_check_email, $email_count);
    mysqli_stmt_fetch($stmt_check_email);
    mysqli_stmt_close($stmt_check_email);

    if ($email_count > 0) {
        // Email already exists, display an error message and sign-in link
        $errors["email"] = "Registration Failed";
        echo '<div class="error-message">This email already exists. 
              <a href="signin.php">Sign in</a>Instead?</div>';
    }
    if (strlen($_POST["password"]) < 8) {
        $errors["password"] = "Password must be at least 8 characters long.";
    }

    $program_query = "SELECT CurrentCapacity, MaxCapacity, StartDate FROM programs WHERE Program_ID = ?";
    $stmt_program = mysqli_prepare($connection, $program_query);
    mysqli_stmt_bind_param($stmt_program, "i", $program_id);
    mysqli_stmt_execute($stmt_program);
    mysqli_stmt_bind_result($stmt_program, $current_capacity, $max_capacity, $start_date);
    mysqli_stmt_fetch($stmt_program);
    mysqli_stmt_close($stmt_program);
    $start_timestamp = strtotime($start_date);
    $current_timestamp = time();

    if ($start_timestamp < $current_timestamp) {
        $errors["program_started"] = "The selected program has already started. Please choose another program.";
    }


    if ($current_capacity >= $max_capacity) {
        $errors["program_full"] = "The selected program is full. Please choose another program.";
    }

    if (empty($errors)) {
        $insert_query = "INSERT INTO Applicants (Full_Name, Mobile_nb, Major, University, Email, pwd) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($connection, $insert_query);
        mysqli_stmt_bind_param($stmt, "ssssss", $full_name, $mobile_nb, $major, $university, $email, $password);

        if (mysqli_stmt_execute($stmt)) {
            $applicant_id = mysqli_insert_id($connection); // Get the ID of the newly inserted applicant
            $insert_applicant_program_query = "INSERT INTO ApplicantPrograms (Applicant_ID, Program_ID) VALUES (?, ?)";
            $stmt_insert_applicant_program = mysqli_prepare($connection, $insert_applicant_program_query);
            mysqli_stmt_bind_param($stmt_insert_applicant_program, "ii", $applicant_id, $program_id);
            mysqli_stmt_execute($stmt_insert_applicant_program);
            mysqli_stmt_close($stmt_insert_applicant_program);
            $insert_query2 = "INSERT INTO certificates (Certificate_File_Path,Applicants_Applicant_ID) VALUES (?, ?)";
            $stmt2 = mysqli_prepare($connection, $insert_query2);
            mysqli_stmt_bind_param($stmt2, "si", $url, $applicant_id);
            mysqli_stmt_execute($stmt2);
            echo '<div class="success-message">Registration successful!</div>';


            $update_query = "UPDATE Programs SET CurrentCapacity = CurrentCapacity + 1 WHERE Program_ID = ?";
            $stmt_update = mysqli_prepare($connection, $update_query);
            mysqli_stmt_bind_param($stmt_update, "i", $program_id);
            mysqli_stmt_execute($stmt_update);
            mysqli_stmt_close($stmt_update);
        } else {

            echo '<div class="error-message">Registration failed. Please try again later.</div>';
        }


        mysqli_stmt_close($stmt);
    }
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Internship Program Registration</title>
    <link rel="stylesheet" type="text/css" href="stylereg.css">
</head>
<style>
    body {
        background-color: #3498db;
        font-family: Arial, sans-serif;
        text-align: center;
        margin: 0;
        padding: 0px;
    }

    .container {
        background-color: #ffffff;
        border-radius: 10px;
        padding: 20px;
        width: 700px;
        margin: 0px auto;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    }

    .logo {
        display: block;
        margin: 0 auto 20px;
        width: 100px;
        height: auto;
    }

    h3 {
        color: #000304;
    }

    form {
        text-align: left;
    }

    label {
        font-weight: bold;
        text-align: left;
        /* Align labels to the left */
    }

    select,
    input[type="text"],
    input[type="email"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    /* Success Message */
    .success-message {
        color: #008000;
        font-weight: bold;
        margin: 10px 0;
    }

    /* Error Message */
    .error-message {
        color: #FF0000;
        font-weight: bold;
        margin: 10px 0;
    }

    /* Info Message */
    .info-message {
        color: #0000FF;
        font-weight: bold;
        margin: 10px 0;
    }

    input[type="submit"] {
        background-color: #3498db;
        color: #fff;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
</style>

<body>
    <div class="container">
        <img src="logo.png" alt="Logo" class="logo">
        <h3>Registration form</h3>
        <form action="registration.php" method="POST">
            <label for="full_name">Full Name:</label>
            <input type="text" id="full_name" name="full_name" value="<?php echo $full_name ?>" required><br>

            <label for="mobile_nb">Mobile Number:</label>
            <input type="text" id="mobile_nb" name="mobile_nb" value="<?php echo $mobile_nb ?>" required><br>

            <label for="university">University:</label>
            <select id="university" name="university" value="<?php echo $university ?>" required>
                <option value="">Select University</option>
                <?php

                include("connection.php");
                $query = "SELECT * FROM Lookup_items WHERE Lookups_Lookup_ID = 1 ORDER BY Item_Name ASC";
                $result = mysqli_query($connection, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' . $row['Item_Name'] . '">' . $row['Item_Name'] . '</option>';
                }

                mysqli_close($connection);
                ?>
            </select><br>

            <label for="major">Major:</label>
            <select id="major" name="major" required>
                <option value="">Select Major</option>
                <?php

                include("connection.php");
                $query = "SELECT * FROM Lookup_items WHERE Lookups_Lookup_ID = 0 ORDER BY Item_Name ASC";
                $result = mysqli_query($connection, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' . $row['Item_Name'] . '">' . $row['Item_Name'] . '</option>';
                }

                mysqli_close($connection);
                ?>
            </select><br>
            <label for="program">Select Program:</label>
            <select id="program" name="program" required>
                <option value="">Select Program</option>
                <?php
                include("connection.php");
                $query = "SELECT * FROM Programs ORDER BY Title ASC";
                $result = mysqli_query($connection, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' . $row['Program_ID'] . '">' . $row['Title'] . '</option>';
                }

                mysqli_close($connection);
                ?>
            </select><br>
            <div class=" error-message" id="program-started-error">
                <?php echo isset($errors["program_started"]) ? $errors["program_started"] : ""; ?>
            </div>
            <div class="error-message" id="program-full-error">
                <?php echo isset($errors["program_full"]) ? $errors["program_full"] : ""; ?>
            </div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Example@gmail.com" value="<?php $email ?>" required><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <div class="error-message" id="password-error">
                <?php echo isset($errors["password"]) ? $errors["password"] : ""; ?>
            </div>
            <input type="submit" value="Register">
        </form>
    </div>
</body>

</html>
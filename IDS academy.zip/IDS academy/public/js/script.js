$(document).ready(function(){

    $('#menu').click(function(){
        $(this).toggleClass('fa-times');
        $('.navbar').toggleClass('nav-toggle');
    });

    $(window).on('load scroll',function(){
        $('#menu').removeClass('fa-times');
        $('.navbar').removeClass('nav-toggle');
    });

});
// Add this JavaScript code to your script or in a separate script file
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var joinButton = document.getElementById("joinButton");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the "Join us" button, open the modal
joinButton.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on the close button, close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Enrolled Programs At IDS Academy</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1 class="heading">You Are Enrolled In:</h1>
</header>
    <section class="service">
    <div class="box-container">
    <?php
include("connection.php");

$email = $_GET["email"];


$id_query = "SELECT ID FROM Applicants WHERE Email = ?";
$stmt_id = mysqli_prepare($connection, $id_query);
mysqli_stmt_bind_param($stmt_id, "s", $email);
mysqli_stmt_execute($stmt_id);
mysqli_stmt_bind_result($stmt_id, $applicant_id);

if (mysqli_stmt_fetch($stmt_id)) {
    mysqli_stmt_close($stmt_id);
    $query = "SELECT Programs.*
              FROM Programs
              JOIN ApplicantPrograms ON Programs.Program_ID = ApplicantPrograms.Program_ID
              WHERE ApplicantPrograms.Applicant_ID = ?";
    
    $stmt_programs = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt_programs, "i", $applicant_id);
    mysqli_stmt_execute($stmt_programs);
    $result_set = mysqli_stmt_get_result($stmt_programs);
    
    if (mysqli_num_rows($result_set) > 0) {
        while ($row = mysqli_fetch_assoc($result_set)) {
            echo '<div class="box">'; 
            echo "<i class='fas fa-code'></i>";
            echo "<h2>" . $row['Title'] . "</h2>";
            echo "<p><strong>Description:</strong> " . $row['Description'] . "</p>";
            echo "<p><strong>Start Date:</strong> " . $row['StartDate'] . "</p>";
            echo "<p><strong>End Date:</strong> " . $row['EndDate'] . "</p>";
            echo "<p><strong>Classroom-Code:</strong><a href='classroom.php'>". $row['Google_Classroom_Code'] . "</a></p>";

            echo "</div>"; 
            echo "<hr>";
        }
    } else {
        echo "<h1>No internship programs enrolled right now.</h1>";
    }

    mysqli_stmt_close($stmt_programs);
} else {
    echo "User with email '$email' not found.";
}

mysqli_close($connection);
?>

    </div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="script.js"></script>

</body>
<footer>
    <p>&copy; 2023 IDS Academy. All rights reserved.</p>
  </footer>
</html>
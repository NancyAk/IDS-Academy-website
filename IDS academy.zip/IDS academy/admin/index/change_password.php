<?php
include("../includes/header.php");
include("../config/connection.php");
$error = $success = $email = $oldpassword = $newpassword = $confirmpassword = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $oldpassword = $_POST['current_password'];
    $newpassword = $_POST['new_password'];
    $confirmpassword = $_POST['confirm_password'];
    if ($newpassword === $confirmpassword) {

        $sql = "SELECT * FROM instructor WHERE pwd='$oldpassword' and Email='$email'";
        $result = mysqli_query($connection, $sql);
        if (mysqli_num_rows($result) === 1) {
            $update_sql = "UPDATE instructor SET pwd='$newpassword' WHERE Email='$email'";
            if (mysqli_query($connection, $update_sql)) {
                $success = "Password updated successfully";
            } else {
                $error = "Error updating password: " . mysqli_error($connection);
            }
        } else {
            $error = "Current Password is incorrect";
        }
    } else {
        $error = "Error fetching the stored password: " . mysqli_error($connection);
    }
}
?>


<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Change Password</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <h1>Change Password</h1>
    <?php
    // Display error message if there is an error
    if (!empty($error)) {
        echo '<div class="alert alert-danger" role="alert">' . $error . '</div>';
    }

    // Display success message if there is a success
    if (!empty($success)) {
        echo '<div class="alert alert-success" role="alert">' . $success . '</div>';
    }
    ?>
    <form action="" method="POST">
        <div class="row mb-3">
            <label for="email" class="col-sm-3 col-form-label">Email:</label>
            <div class="col-sm-6">
                <input type="email" name="email" class="form-control" required><br>
            </div>
            <label for="current_password" class="col-sm-3 col-form-label">Current Password:</label>
            <div class="col-sm-6">
                <input type="password" name="current_password" class="form-control" required><br>
            </div>
            <label for="new_password" class="col-sm-3 col-form-label">New Password:</label>
            <div class="col-sm-6">
                <input type="password" name="new_password" class="form-control" required><br>
            </div>
            <label for="confirm_password" class="col-sm-3 col-form-label">Confirm New Password:</label>

            <div class="col-sm-6">
                <input type="password" name="confirm_password" class="form-control" required><br>
            </div>
            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="../index.php" role="button">Cancel</a>
                </div>
            </div>
    </form>
    <?php
    include("../includes/footer.php"); ?>
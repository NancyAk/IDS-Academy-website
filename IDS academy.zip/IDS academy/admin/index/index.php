<?php
include("../includes/header.php");
include("../config/connection.php");
$email = $_GET['email'];
// Query to get counts
$query_admin_name = "SELECT Full_Name FROM instructor WHERE Email='$email'";
$result_admin_name = $connection->query($query_admin_name);

// Check for errors in query execution
if (!$result_admin_name) {
    die("Query error: " . $conn->error);
}

// Fetch the admin's name
$row_admin_name = $result_admin_name->fetch_assoc();
$admin_name = $row_admin_name['Full_Name'];
$query_applicants = "SELECT COUNT(*) as applicant_count FROM applicants";
$query_programs = "SELECT COUNT(*) as program_count FROM programs";
$query_instructors = "SELECT COUNT(*) as instructor_count FROM instructor";
$query_lookups = "SELECT COUNT(*) as lookup_count FROM lookups";

// Execute the queries
$result_applicants = $connection->query($query_applicants);
$result_programs = $connection->query($query_programs);
$result_instructors = $connection->query($query_instructors);
$result_lookups = $connection->query($query_lookups);

// Check for errors in query execution
if (!$result_applicants || !$result_programs || !$result_instructors || !$result_lookups) {
    die("Query error: " . $conn->error);
}

// Fetch the counts
$row_applicants = $result_applicants->fetch_assoc();
$row_programs = $result_programs->fetch_assoc();
$row_instructors = $result_instructors->fetch_assoc();
$row_lookups = $result_lookups->fetch_assoc();
?>
<!DOCTYPE html>
<html>

<head>
    <title>IDS Academy Admin Panel</title>
    <style>
        .admin-name {
            font-size: 28px;
            color: #333;
            /* Choose an elegant text color */
            margin-top: 20px;
            font-family: "Georgia", serif;
            /* Choose an elegant font */
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: center;
        }

        .count-box {
            width: 200px;
            height: 200px;
            margin: 20px;
            text-align: center;
            line-height: 1.5;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            background: linear-gradient(45deg, #00c6ff, #0072ff);
            color: #fff;
        }

        .count-box h3 {
            font-size: 24px;
            margin: 10px 0;
        }

        .count-box p {
            font-size: 36px;
            margin: 0;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <h1>Admin Panel</h1>
    <div class="admin-name">
        <?php echo "Administrator: $admin_name"; ?>
    </div>
    <div class="container">

        <!-- Applicants Count Box -->
        <div class="count-box">
            <h3>Applicants</h3>
            <p><?php echo $row_applicants['applicant_count']; ?></p>
        </div>

        <!-- Programs Count Box -->
        <div class="count-box">
            <h3>Programs</h3>
            <p><?php echo $row_programs['program_count']; ?></p>
        </div>

        <!-- Instructors Count Box -->
        <div class="count-box">
            <h3>Instructors</h3>
            <p><?php echo $row_instructors['instructor_count']; ?></p>
        </div>

        <!-- Lookups Count Box -->
        <div class="count-box">
            <h3>Lookups</h3>
            <p><?php echo $row_lookups['lookup_count']; ?></p>
        </div>
    </div>
    <?php
    include("../includes/footer.php"); ?>
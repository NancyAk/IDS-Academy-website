<!DOCTYPE html>
<html>

<head>

    <title>Admin LOGIN</title>
    <style>
        body {
            background: #1690A7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
        }

        * {
            font-family: sans-serif;
            box-sizing: border-box;
        }

        form {
            width: 400px;
            border: 2px solid #ccc;
            padding: 30px;
            background: #fff;
            border-radius: 15px;
        }

        h2 {
            text-align: center;
            margin-bottom: 40px;
        }

        input {
            display: black;
            border: 2px solid #ccc;
            width: 95%;
            padding: 10px;
            margin: 10px auto;
            border-radius: 5px;
        }

        label {
            color: #888;
            font-size: 15px;
            padding: 10px;
        }

        button {
            float: right;
            background: #555;
            padding: 10px 15px;
            color: #fff;
            border-radius: 5px;
            margin-right: 10px;
            border: none;
        }

        button:hover {
            opacity: .7;
        }

        .error {
            background: #f2DEDE;
            color: #A94;
        }

        .hello {
            color: green;
            font-size: 16px;
            margin-top: 5px;
        }

        .error {
            color: red;
            font-size: 16px;
            margin-top: 5px;
        }

        .logo {
            display: block;
            margin: 0 auto 20px;
            width: 100px;
            height: auto;
        }
    </style>
</head>

<body>
    <form action="" method="post">
        <?php
        $fail = "";
        include("../config/connection.php");
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $email = $_POST['Email'];
            $password = $_POST['pass'];
            $sql = "SELECT * FROM instructor WHERE Email='$email' AND pwd='$password'";
            $result = mysqli_query($connection, $sql);
            if (mysqli_num_rows($result) === 1) {
                header("Location: index.php?email=$email");
            } else {
                $fail = "INVALID EMAIL OR PASSWORD";
            }
        }
        ?>
        <div>
            <img src="../assets/img/logo.png" alt="Logo" class="logo">
            <Label for="Email"></Label>
            <input type="text" id="Email" name="Email" placeholder="Admin Email" required>
        </div>
        <br>
        <div>
            <Label for="pass"></Label>
            <input type="password" id="pass" name="pass" placeholder="Password" required>
        </div>
        <button type="submit">login</button>
        <br>
        <div class="error"><?php echo $fail; ?></div>


    </form>
</body>

</html>
<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "idsdb";
$connection = mysqli_connect($host, $username, $password, $database);
if (!$connection) {
    die("COnnection Failed: " . mysqli_connect_error());
}

<?php
include("../includes/header.php");
include("../config/connection.php");
$id = $_GET['ID'];
$sql = "SELECT * FROM instructor where ID=$id";
$result = $connection->query($sql);
$row = $result->fetch_assoc();
$name = $row['Full_Name'];
$email = $row['email'];
$pwd = $row['pwd'];
$success = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['Full_Name'];
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $sql = "UPDATE instructor
SET Full_Name= '$name', email='$email', pwd='$pwd'
WHERE ID=$id";
    $result = $connection->query($sql);
    if ($connection->query($sql) === TRUE) {
        $success = "Edited Successfully";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Instructor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <form method="POST">
        <div class="container my-5">
            <h2>Edit</h2>
            <div class="row mb-3">
                <label for="name" class="col-sm-3 col-form-label">ID:</label>
                <div class="col-sm-6">
                    <input type="text" id="name" class="form-control" name="ID" value="<?php echo $id; ?>" required>
                </div>
                <label for="name" class="col-sm-3 col-form-label">Full_Name</label>
                <div class="col-sm-6">
                    <input type="text" id="Full-Name" class="form-control" name="Full_Name" value="<?php echo $name; ?>" required>
                </div>
                <label for="name" class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-6">
                    <input type="text" id="name" class="form-control" name="email" value="<?php echo $email; ?>" required>
                </div>
                <label for="name" class="col-sm-3 col-form-label">password</label>
                <div class="col-sm-6">
                    <input type="text" id="name" class="form-control" name="pwd" value="<?php echo $pwd; ?>" required>
                </div>
                <br>
                <?php echo "<h3>$success</h3>"; ?>
                <div class="row mb-3">
                    <div class="offset-sm-3 col-sm-3 d-grid">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <div class="col-sm-3 d-grid">
                        <a class="btn btn-outline-primary" href="../instructor/instructor.php" role="button">Cancel</a>
                    </div>
                </div>
    </form>
    </div>
</body>

</html>
<?php
include("../includes/footer.php"); ?>
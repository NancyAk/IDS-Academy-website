<?php
include("../includes/header.php"); ?>

<body>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <div class="container">
        <h2>List of Instructors</h2>
        <a class='btn btn-primary bt-sm' href='new.php' role="button">New Instructor</a>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full_Name</th>
                    <th>email</th>
                    <th>pwd</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("../config/connection.php");
                $sql = "SELECT * FROM instructor";
                $result = $connection->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>
                      $row[ID]
                    </td>
                      <td>$row[Full_Name]</td>
                    <td>$row[email]</td>
                     <td>$row[pwd]</td>";
                    if ($row['ID'] != 1) {
                        echo "<td>
                        <a class='btn btn-primary bt-sm' href='edit.php?ID=$row[ID]'>Edit</a>
                       
                    </td>
                </tr>";
                    }
                }
                ?>
            </tbody>
        </table>


    </div>
    <?php
    include("../includes/footer.php");
    ?>
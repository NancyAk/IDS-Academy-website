<?php
include("../includes/header.php");
include("../config/connection.php");
$name = $major = $email = $pwd = $uni = $nb = $success = $programOffered = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $pwd = $_POST["pwd"];
    $program_ID = $_POST["program"];
    $sql = "INSERT INTO instructor   (email,pwd,Full_Name,program_ID) Values('$email','$pwd','$name','$program_ID')";
    $result = $connection->query($sql);
    $success = "Added Successfully";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create instructor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container my-5">
        <h2>New</h2>
        <form method="POST">
            <div class="row mb-3">
                <label for="name" class="col-sm-3 col-form-label">Full_Name</label>
                <div class="col-sm-6">
                    <input type="text" id="name" class="form-control" name="name" value="<?php echo $name; ?>" required>
                </div>
                <label for="email" class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-6">
                    <input type="text" id="major" class="form-control" name="email" value="<?php echo $email; ?>" required>
                </div>
                <label for="pwd" class="col-sm-3 col-form-label">Password</label>
                <div class="col-sm-6">
                    <input type="text" id="pwd" class="form-control" name="pwd" value="<?php echo $pwd; ?>" required>
                </div>
                <label for="program" class="col-sm-3 col-form-label">Program</label>
                <div class="col-sm-6">
                    <select id="program" name="program" class="form-select" required>
                        <option value="">Select Program</option>
                        <?php
                        $query = "SELECT * FROM Programs ORDER BY Title ASC";
                        $result = mysqli_query($connection, $query);

                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<option value="' . $row['Program_ID'] . '">' . $row['Title'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
            </div>
            <br>
            <?php echo "<h3>$success</h3>"; ?>
            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="../instructor/instructor.php" role="button">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>

</html>
<?php
include("../includes/footer.php"); ?>
<?php
include("../includes/header.php");
include("../config/connection.php");
$programID = $title = $description = $startDate = $endDate = $maxCapacity = $currentCapacity = $googleClassroomCode = $instructorID = $success = "";

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['ID'])) {
    $programID = $_GET['ID'];
    $query = "SELECT * FROM programs WHERE Program_ID = '$programID'";
    $result = mysqli_query($connection, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        $title = $row['Title'];
        $description = $row['Description'];
        $startDate = $row['StartDate'];
        $endDate = $row['EndDate'];
        $maxCapacity = $row['MaxCapacity'];
        $currentCapacity = $row['CurrentCapacity'];
        $googleClassroomCode = $row['Google_Classroom_Code'];
        $instructorID = $row['Instructors_InstructorID'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST["title"];
    $description = $_POST["description"];
    $startDate = $_POST["start_date"];
    $endDate = $_POST["end_date"];
    $maxCapacity = $_POST["max_capacity"];
    $currentCapacity = $_POST["current_capacity"];
    $googleClassroomCode = $_POST["google_classroom_code"];
    $instructorID = $_POST["instructor_id"];

    $sql = "UPDATE Programs
            SET Title = '$title', Description = '$description', StartDate = '$startDate', EndDate = '$endDate',
                MaxCapacity = '$maxCapacity', CurrentCapacity = '$currentCapacity',
                Google_Classroom_Code = '$googleClassroomCode', Instructors_InstructorID = '$instructorID'
            WHERE Program_ID = '$programID'";

    if ($connection->query($sql)) {
        $success = "Program Updated Successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Program</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <h3>Edit Program</h3>
    <div class="container my-2">
        <form method="POST">
            <div class="row mb-2">
                <label for="title" class="col-sm-3 col-form-label">Title</label>
                <div class="col-sm-6">
                    <input type="text" id="title" class="form-control" name="title" value="<?php echo $title; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="description" class="col-sm-3 col-form-label">Description</label>
                <div class="col-sm-6">
                    <input type="text" id="description" class="form-control" name="description" value="<?php echo $description; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="start_date" class="col-sm-3 col-form-label">Start Date</label>
                <div class="col-sm-6">
                    <input type="date" id="start_date" class="form-control" name="start_date" value="<?php echo $startDate; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="end_date" class="col-sm-3 col-form-label">End Date</label>
                <div class="col-sm-6">
                    <input type="date" id="end_date" class="form-control" name="end_date" value="<?php echo $endDate; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="max_capacity" class="col-sm-3 col-form-label">Max Capacity</label>
                <div class="col-sm-6">
                    <input type="number" id="max_capacity" class="form-control" name="max_capacity" value="<?php echo $maxCapacity; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="current_capacity" class="col-sm-3 col-form-label">Current Capacity</label>
                <div class="col-sm-6">
                    <input type="number" id="current_capacity" class="form-control" name="current_capacity" value="<?php echo $currentCapacity; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="google_classroom_code" class="col-sm-3 col-form-label">Google Classroom Code</label>
                <div class="col-sm-6">
                    <input type="text" id="google_classroom_code" class="form-control" name="google_classroom_code" value="<?php echo $googleClassroomCode; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="instructor_id" class="col-sm-3 col-form-label">Instructor ID</label>
                <div class="col-sm-6">
                    <select id="instructor_id" name="instructor_id" class="form-select" required>
                        <option value="">Select Instructor</option>
                        <?php
                        $query = "SELECT ID, Full_Name FROM instructor ORDER BY Full_Name ASC";
                        $result = mysqli_query($connection, $query);

                        while ($row = mysqli_fetch_assoc($result)) {
                            $selected = ($row['ID'] == $instructorID) ? 'selected' : '';
                            echo '<option value="' . $row['ID'] . '" ' . $selected . '>' . $row['Full_Name'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
            </div>
            <br>
            <?php echo "<h3>$success</h3>"; ?>
            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="../program/program.php" role="button">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>

</html>

<?php
include("../includes/footer.php");
?>
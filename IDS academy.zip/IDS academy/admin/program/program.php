<?php
include("../includes/header.php"); ?>

<body>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <div class="container">
        <h2>List of Programs</h2>
        <a class='btn btn-primary bt-sm' href='new.php' role="button">New program</a>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>StartDate</th>
                    <th>EndDate</th>
                    <th>MaxCapacity</th>
                    <th>CurrentCapacity</th>
                    <th>instructor_ID</th>


                </tr>
            </thead>
            <tbody>
                <?php
                include("../config/connection.php");
                $sql = "SELECT * FROM programs";
                $result = $connection->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>
                      $row[Program_ID]
                    </td>
                    <td>$row[Title]</td>
                     <td>$row[StartDate]</td>
                      <td>$row[EndDate]</td>
                       <td>$row[MaxCapacity]</td>
                        <td>$row[CurrentCapacity]</td>
                         <td>$row[Instructors_InstructorID]</td>
                      <td>
                        <a class='btn btn-primary bt-sm' href='edit.php?ID=$row[Program_ID]'>Edit</a>
                       
                    </td>
                </tr>";
                }
                ?>
            </tbody>
        </table>


    </div>
    <?php
    include("../includes/footer.php");
    ?>
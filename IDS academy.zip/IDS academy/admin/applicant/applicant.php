<?php
include("../includes/header.php"); ?>

<body>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <div class="container">
        <h2>List of Applicants:</h2>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full_Name</th>
                    <th>Mobile_nb</th>
                    <th>Major</th>
                    <th>University</th>
                    <th>Email</th>
                    <th>Password</th>

                </tr>
            </thead>
            <tbody>
                <?php
                include("../config/connection.php");
                $sql = "SELECT * FROM applicants";
                $result = $connection->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>$row[ID]</td>
                     <td>$row[Full_Name]</td>
                      <td>$row[Mobile_nb]</td>
                       <td>$row[Major]</td>
                       <td>$row[University]</td>
                       <td>$row[Email]</td>
                       <td>$row[pwd]</td>
                </tr>";
                }
                ?>
            </tbody>
        </table>


    </div>
    <?php
    include("../includes/footer.php");
    ?>
<?php
include("../includes/header.php"); ?>

<body>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <div class="container">
        <h2>List of pages</h2>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("../config/connection.php");
                $sql = "SELECT * FROM pages";
                $result = $connection->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>$row[Page_ID]</td>
                     <td>$row[Title]</td>
                       <td>
                        <a class='btn btn-primary bt-sm' href='edit.php?ID=$row[Page_ID]'>Edit</a>
                       
                    </td>
                </tr>";
                }
                ?>
            </tbody>
        </table>


    </div>
    <?php
    include("../includes/footer.php");
    ?>
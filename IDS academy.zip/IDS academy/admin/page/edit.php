<?php
include("../includes/header.php");
include("../config/connection.php");
$title = $body = $success = "";
$pageID = $_GET['ID'];
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['ID'])) {
    $pageID = $_GET['ID'];
    $query = "SELECT * FROM pages WHERE Page_ID = '$pageID'";
    $result = mysqli_query($connection, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        $title = $row['Title'];
        $body = $row['Body'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST["Title"];
    $body = $_POST["Body"];
    $sql = "UPDATE pages
            SET Title = '$title', Body = '$body'
            WHERE Page_ID = '$pageID'";

    if ($connection->query($sql)) {
        $success = "Page Updated Successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <h3>Edit Page</h3>
    <div class="container my-2">
        <form method="POST">
            <div class="row mb-2">
                <label for="page_id" class="col-sm-3 col-form-label">Page ID</label>
                <div class="col-sm-6">
                    <input type="text" id="page_id" class="form-control" name="page_id" value="<?php echo $pageID; ?>" readonly>
                </div>
            </div>
            <div class="row mb-2">
                <label for="title" class="col-sm-3 col-form-label">Title</label>
                <div class="col-sm-6">
                    <input type="text" id="Title" class="form-control" name="Title" value="<?php echo $title; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="body" class="col-sm-3 col-form-label">Body</label>
                <div class="col-sm-6">
                    <textarea id="Body" class="form-control" name="Body" rows="4" required><?php echo $body; ?></textarea>
                </div>
            </div>
            <br>
            <?php echo "<h3>$success</h3>"; ?>
            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="../page/page.php" role="button">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>

</html>

<?php
include("../includes/footer.php");
?>
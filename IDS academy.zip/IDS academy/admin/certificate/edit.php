<?php
include("../includes/header.php");
include("../config/connection.php");
$certificateID =  $certificateFilePath = $applicantID = $success = "";

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['ID'])) {

    $certificateID = $_GET['ID'];
    $query = "SELECT * FROM certificates WHERE Certificate_ID = '$certificateID'";
    $result = mysqli_query($connection, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        $certificateFilePath = $row['Certificate_File_Path'];
        $applicantID = $row['Applicants_Applicant_ID'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $certificateFilePath = $_POST["certificate_file_path"];
    $applicantID = $_POST["applicant_id"];

    $sql = "UPDATE Certificates
            SET 
                Certificate_File_Path = '$certificateFilePath', Applicants_Applicant_ID = '$applicantID'
            WHERE Certificate_ID = '$certificateID'";

    if ($connection->query($sql)) {
        $success = "Certificate Updated Successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Certificate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <h3>Edit Certificate</h3>
    <div class="container my-2">
        <form method="POST">
            <div class="row mb-2">
                <label for="certificate_id" class="col-sm-3 col-form-label">Certificate ID</label>
                <div class="col-sm-6">
                    <input type="text" id="certificate_id" class="form-control" name="certificate_id" value="<?php echo $certificateID; ?>" readonly>
                </div>
            </div>
            <div class="row mb-2">
                <label for="certificate_file_path" class="col-sm-3 col-form-label">Certificate File Path</label>
                <div class="col-sm-6">
                    <input type="text" id="certificate_file_path" class="form-control" name="certificate_file_path" value="<?php echo $certificateFilePath; ?>" required>
                </div>
            </div>
            <div class="row mb-2">
                <label for="applicant_id" class="col-sm-3 col-form-label">Applicant ID</label>
                <div class="col-sm-6">
                    <input type="text" id="applicant_id" class="form-control" name="applicant_id" value="<?php echo $applicantID; ?>" required>
                </div>
            </div>
            <br>
            <?php echo "<h3>$success</h3>"; ?>
            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="../certificate/certificate.php" role="button">Cancel</a>
                </div>
            </div>
        </form>
    </div>

    <?php
    include("../includes/footer.php");
    ?>
 <footer class="footer pt-5">
     <div class="container-fluid">
         <div class="row align-items-center justify-content-lg-between">
             <div class="col-lg-6 mb-lg-0 mb-4">
             </div>
         </div>
     </div>
 </footer>
 <script src="../assets/js/bootstrap.bundle.min.js"></script>
 <script src="../assets/js/perfect-scrollbar.min.js"></script>
 <script src="../assets/js/smooth-scrollbar.min.js"></script>
 </body>

 </html>